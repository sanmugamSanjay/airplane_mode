# Copyright (c) 2024, Sanmugam and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from frappe import _
import random


class AirplaneTicket(Document):
	def on_submit(self):
		if self.status != "Boarded":
			frappe.throw("Status not equlat to boarded")
	def before_save(self):
		total=0
		if len(self.add_ons) > 0: 
			total=self.calculation(self.add_ons)
		self.total_amount=self.flight_price +total
	
	def calculation(self,items):
		total=0
		for item in items:
			total=total+item.amount
		return total
		
	def before_insert(self):
		d = random.randint(1, 100)
		rd = random.choice(['A', 'B', 'C', 'D', 'E'])
		self.seat = f"{d}{rd}"

	def validate(self):
		# frappe.response["lenth",len(self.add_ons),"test"]
		# frappe.response[len(self.add_ons)]
		# frappe.errprint(frappe.as_json(data.item))
		if len(self.add_ons) > 0:
			items = []
			for data in self.add_ons:
				if data.item in items:
					frappe.throw(_("Item ({0}) already exists").format(data.item))
				else:
					items.append(data.item)




